module.exports = {
  reactStrictMode: true,
  typescript: {
    tsconfigPath: './tsconfig.json'
  }
}
